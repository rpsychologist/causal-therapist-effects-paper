#' @export
marginalize <- function(object, R, ...) {
    UseMethod("marginalize")
}
