library(testthat)
library(dplyr)
library(powerlmm)
library(lme4)

test_check("powerlmm")
